#!/bin/bash
# Affichage de l'utilisation golbale du disque et les détails sur le répertoire courant avec du
df -h
du -sh ./* 2>/dev/null